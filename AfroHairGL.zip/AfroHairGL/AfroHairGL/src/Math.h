#ifndef AFROHAIRGL_MATH_H
#define AFROHAIRGL_MATH_H

namespace AfroHairGL {

    constexpr float PI = 3.1415926535f;
    constexpr float RadToDeg = 180.0f / PI;
    constexpr float DegToRad = PI / 180.0f;

    // A 3D vector.
    struct Vector3 {
        // The x, y, and z components of the vector.
        float x, y, z;

        // Constructs a new Vector3 with the given x, y, and z components.
        Vector3(float x, float y, float z) : x(x), y(y), z(z) {}

        // Constructs a new Vector3 with all components set to 0.
        Vector3() : x(0.0f), y(0.0f), z(0.0f) {}

        // Returns the value of the specified component.
        float operator[](size_t i) const { return m[i]; }

        // Returns a reference to the specified component.
        float& operator[](size_t i) { return m[i]; }

        // Returns the sum of this vector and the given vector.
        Vector3 operator+(const Vector3& other) const {
            return Vector3(x + other.x, y + other.y, z + other.z);
        }
        // Returns the difference of this vector and the given vector.
        Vector3 operator-(const Vector3& other) const {
            return Vector3(x - other.x, y - other.y, z - other.z);
        }
        // Returns the product of this vector .
        Vector3 operator*(float value) const { return Vector3(x * value, y * value, z * value); }
        // Returns the quotient of this vector.
        Vector3 operator/(float value) const { return Vector3(x / value, y / value, z / value); }
        // Adds the given vector to this vector.
        Vector3& operator+=(const Vector3& other) {
            x += other.x;
            y += other.y;
            z += other.z;
            return *this;
        }
        // Subtracts the given vector from this vector.
        Vector3& operator-=(const Vector3& other) {
            x -= other.x;
            y -= other.y;
            z -= other.z;
            return *this;
        }
        // Multiplies this vector by the given scalar.
        Vector3& operator*=(float value) {
            x *= value;
            y *= value;
            z *= value;
            return *this;
        }
        // Divides this vector by the given scalar.
        Vector3& operator/=(float value) {
            x /= value;
            y /= value;
            z /= value;
            return *this;
        }
        // Returns the length of this vector.
        float Length() const { return std::sqrt(x * x + y * y + z * z); }
        // Returns the squared length of this vector.
        float Length2() const { return x * x + y * y + z * z; }
        // Returns a version of this vector.
        Vector3 Normalized() const { return *this / Length(); }
        // Normalizes this vector.
        Vector3& Normalize() {
            float length = Length();
            if (length > 0.0f) {
                *this /= length;
            }
            return *this;
        }
        // Calculate the curl of the given vector field.
        Vector3 Curl(const Vector3& v1, const Vector3& v2, const Vector3& v3)
        {
            // Calculate the cross product of v1 and v2.
            Vector3 v1CrossV2 = Vector3::Cross(v1, v2);

            // Calculate the cross product of v3 and v1CrossV2.
            return Vector3::Cross(v3, v1CrossV2);
        }

        // Calculate the curl of the given vector field at the given position.
        Vector3 Curl(const Vector3& v1, const Vector3& v2, const Vector3& v3, const Vector3& pos)
        {
            // Calculate the curl of the vector field.
            Vector3 curl = Curl(v1, v2, v3);

            // Normalize the curl.
            curl = curl.Normalized();

            // Return the curl at the given position.
            return curl;
        }

        // Returns the cross product of this vector and the given vector.
        static Vector3 Cross(const Vector3& a, const Vector3& b) {
            return Vector3(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x);
        }
        // Returns the dot product of this vector and the given vector.
        static float Dot(const Vector3& a, const

            // This struct represents a 4x4 matrix.
            struct Matrix4
        {
            // The elements of the matrix.
            Vector4 m[4];
            // Constructor that initializes the matrix to zero.
            Matrix4()
            {
                SetZero();
            }
            // Sets the matrix to the identity matrix.
            void SetIdentity();

            // Sets the matrix to zero.
            void SetZero();
            // Creates a perspective projection matrix.
            static Matrix4 Perspective(float fovy, float aspect, float zNear, float zFar);
            // Creates a look-at matrix.
            static Matrix4 LookAt(const HairGL::Vector3& eye, const HairGL::Vector3& at, const HairGL::Vector3& up);
            // Creates a translation matrix.
            static Matrix4 Translation(float x, float y, float z);
            // Creates a rotation matrix around the x-axis.
            static Matrix4 RotateX(float angle);
            // Creates a rotation matrix around the y-axis.
            static Matrix4 RotateY(float angle);
            // Creates a rotation matrix around the z-axis.
            static Matrix4 RotateZ(float angle);
            // Returns the inverse of the matrix.
            Matrix4 EuclidianInversed() const;
            // Multiplies the matrix by another matrix.
            Matrix4 operator*(const Matrix4& other) const;

            // Multiplies the matrix by a vector.
            Vector4 operator*(const Vector4& v) const;
        };
        // This struct represents a 3x3 matrix.
        struct Matrix3
        {
            // The elements of the matrix.
            Vector3 m[3];
            // Constructor that initializes the matrix to zero.
            Matrix3()
            {
                SetZero();
            }
            // Sets the matrix to the identity matrix.
            void SetIdentity();
            // Sets the matrix to zero.
            void SetZero();
            // Multiplies the matrix by another matrix.
            Matrix3 operator*(const Matrix3& other) const;
        };
        // This struct represents a quaternion.
        struct Quaternion
        {
            // The elements of the quaternion.
            union
            {
                struct
                {
                    float m[4];
                };
                struct
                {
                    float x, y, z, w;
                };
            };
            // Constructor that initialisequaternion to zero.
            Quaternion(float x = 0.0f, float y = 0.0f, float z = 0.0f, float w = 1.0f) :
                x(x),
                y(y),
                z(z),
                w(w)
            {
            }
            // Constructor that initialises the quaternion from an axis-angle pair.
            Quaternion(const Vector3& axis, float angle);
            // Returns the element at the specified index.
            float operator[](unsigned int i) const
            {
                return m[i];
            }
            // Returns a reference to the element at the specified index.
            float& operator[](unsigned int i)
            {
                return m[i];
            }
            // Returns the inverse of the quaternion.
            Quaternion Inversed() const;
            // Creates a quaternion from a rotation matrix.
            static Quaternion FromMatrix(const Matrix3& matrix);
            // Multiplies the quaternion by a vector.
            Vector3 operator*(const Vector3& v) const;
            // Multiplies the quaternion by another quaternion.
            Quaternion operator*(const Quaternion& other) const;
        };