#ifndef AFROHAIRGL_H
#define AFROHAIRGL_H

#include "Math.h"
#include "HairTypes.h"
#include <stdint.h>

namespace AfroHairGL
{
    class HairRender;
    class HairAsset;
    class AfroInst;

    class HairSystem
    {
    public:
        HairSystem();
        HairSystem(const HairSystem&) = delete;
        void Simulate(AfroInst* instance, float timeStep = 1.0f / 60.0f) const;
        void Render(const AfroInst* instance, const Matrix4& viewMatrix, const Matrix4& projectionMatrix) const;
        HairAsset* LoadAsset(const char* path) const;
        void DestroyAsset(HairAsset* asset) const;
        AfroInst* CreateInstance(const HairAsset* asset) const;
        void UpdateInstanceSettings(AfroInst* instance, const AfroInstSettings& settings) const;
        void DestroyInstance(AfroInst* instance) const;
        ~HairSystem();

    private:
        HairRender* renderer;
    };
}

#endif