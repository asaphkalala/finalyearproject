#ifndef AFROHAIRGL_HAIRTYPES_H
#define AFROHAIRGL_HAIRTYPES_H

#include <stdint.h>
#include <afrohairgl/Math.h>

namespace AfroHairGL {

    struct HairAssetDescriptor {
        uint32_t segmentsCount;
        uint32_t guidesCount;
        Vector4* positions;
    };

    struct AfroInstSettings {
        // GLOBAL
        bool renderHair;  // Whether to render the hair.
        Matrix4 modelMatrix;  // The model matrix for the hair.
        float tessFact;  // The tessellation factor for the hair.
        float density;  // The density of the hair.
        // SHAPE
        float rootWidth;  // The width of the root of the hair.
        float tipWidth;  // The width of the tip of the hair.
        float startThin;  // The amount of thinning at the start of the hair.
        // SIMULATION
        float stiffGlobal;  // The global stiffness of the hair.
        float stiffLocal;  // The local stiffness of the hair.
        float hairCurliness;  // The hairCurliness of the hair.
        Vector4 color;  // The colour of the hair.

        AfroInstSettings() : //starting values
            renderHair(true),
            tessFact(1.0f),
            density(16.0f),
            rootWidth(0.001f),
            tipWidth(0.005f),
            startThin(0.5f),
            color(0, 0, 0, 1),
            stiffGlobal(0),
            stiffLocal(0),
            hairCurliness(0),
        {
          modelMatrix.SetIdentity();
        }
    };
}

#endif