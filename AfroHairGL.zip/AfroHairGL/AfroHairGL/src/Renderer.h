#ifndef AFROHAIRGL_RENDERER_H
#define AFROHAIRGL_RENDERER_H

#include <stdint.h>
#include <afrohairgl/Math.h>
#include "Common.h"

namespace AfroHairGL
{
    class HairRender
    {
    public:
        HairRender();
        HairRender(const HairRender&) = delete;
        void Simulate(AfroInst* instance, float timeStep) const;
        void Render(const AfroInst* instance, const Matrix4& viewMatrix, const Matrix4& projectionMatrix) const;
        ~HairRender();

    private:
        uint32_t emptyVertexArrayID;
        uint32_t simulationProgramID;
        uint32_t hairRenderingProgramID;
        uint32_t hairDataBufferID;
        uint32_t sceneDataBufferID;
        uint32_t simulationDataBufferID;

        uint32_t CreateSimulationProgram();
        uint32_t CreateHairRenderingProgram();

        std::string shaderIncludeSrc;
    };
}

#endif