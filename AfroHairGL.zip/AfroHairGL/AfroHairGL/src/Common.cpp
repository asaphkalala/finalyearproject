#include "Common.h"

namespace AfroHairGL
{
    std::string LoadFile(const char* path) // TODO: Make this more efficient by using a buffer
    
    {
        auto file = fopen(path, "rb");
        fseek(file, 0, SEEK_END);
        int size = ftell(file);
        fseek(file, 0, SEEK_SET);

        std::string str(size, '\0');
        fread(&str[0], 1, size, file);
        fclose(file);

        return str;
    }
}
