#include "HairRender.h"
#include "gl/GLUtils.h"
#include <vector>
#include <algorithm>
#include <afrohairgl/Math.h>
#include "shaders/ShaderTypes.h"

namespace AfroHairGL
{
    const std::string GLSLVersion = "#version 430 core\n";

    HairRender::HairRender() :
        simulationProgramID(0),
        hairRenderingProgramID(0),
        emptyVertexArrayID(0)
    {
        glGenVertexArrays(1, &emptyVertexArrayID);

        glGenBuffers(1, &hairDataBufferID);
        glBindBuffer(GL_UNIFORM_BUFFER, hairDataBufferID);
        glBufferData(GL_UNIFORM_BUFFER, sizeof(HairRenderData), nullptr, GL_DYNAMIC_DRAW);
        glBindBuffer(GL_UNIFORM_BUFFER, 0);

        glGenBuffers(1, &sceneDataBufferID);
        glBindBuffer(GL_UNIFORM_BUFFER, sceneDataBufferID);
        glBufferData(GL_UNIFORM_BUFFER, sizeof(SceneRenderData), nullptr, GL_DYNAMIC_DRAW);
        glBindBuffer(GL_UNIFORM_BUFFER, 0);

        glGenBuffers(1, &lightDataBufferID);
        glBindBuffer(GL_UNIFORM_BUFFER, lightDataBufferID);
        glBufferData(GL_UNIFORM_BUFFER, sizeof(LightRenderData), nullptr, GL_DYNAMIC_DRAW);
        glBindBuffer(GL_UNIFORM_BUFFER, 0);

        shaderIncludeSrc = LoadFile("afrohairglshaders/ShaderTypes.h");

        simulationProgramID = CreateSimulationProgram();
        hairRenderingProgramID = CreateHairRenderingProgram();
    }

    void HairRender::Simulate(AfroInst* instance, float timeStep) const
    {
        auto asset = instance->asset;
        glUseProgram(simulationProgramID);

        glBindBufferBase(GL_SHADER_STORAGE_BUFFER, REST_POSITIONS_BUFFER_BINDING, asset->restPositionsBufferID);
        glBindBufferBase(GL_SHADER_STORAGE_BUFFER, POSITIONS_BUFFER_BINDING, instance->positionsBufferID);
        glBindBufferBase(GL_SHADER_STORAGE_BUFFER, PREVIOUS_POSITIONS_BUFFER_BINDING, instance->prevPossBufferID);
        glBindBufferBase(GL_SHADER_STORAGE_BUFFER, TANGENTS_DISTANCES_BINDING, asset->tangentsDistancesBufferID);
		glBindBufferBase(GL_SHADER_STORAGE_BUFFER, REF_VECTORS_BINDING, asset->refVectorsBufferID);
		glBindBufferBase(GL_SHADER_STORAGE_BUFFER, GLOBAL_ROTATIONS_BINDING, asset->globalRotationsBufferID);
		glBindBufferBase(GL_SHADER_STORAGE_BUFFER, DEBUG_BUFFER_BINDING, asset->debugBufferID);

        int verticesPerStrand = asset->segmentsCount + 1;
        glUniformMatrix4fv(glGetUniformLocation(simulationProgramID, "modelMatrix"), 1, false, (float*)instance->settings.modelMatrix.m);
        glUniform1i(glGetUniformLocation(simulationProgramID, "verticesPerStrand"), verticesPerStrand);
        glUniform1f(glGetUniformLocation(simulationProgramID, "timeStep"), timeStep);
        glUniform1f(glGetUniformLocation(simulationProgramID, "stiffGlobal"), instance->settings.stiffGlobal); 
		glUniform1f(glGetUniformLocation(simulationProgramID, "stiffLocal"), (std::min)(instance->settings.stiffLocal, 0.95f) * 0.5f);
        glUniform1f(glGetUniformLocation(simulationProgramID, "hairCurliness"), instance->settings.hairCurliness);
        glUniform3f(glGetUniformLocation(simulationProgramID, "gravity"), 0.0f, -9.8f, 0.0f);
        glUniform1i(glGetUniformLocation(simulationProgramID, "lenConstrIter"), 5); // 
		glUniform1i(glGetUniformLocation(simulationProgramID, "locShapeIter"), 10);
		

        glDispatchCompute(instance->asset->guidesCount, 1, 1); // 
        glUseProgram(0);

        glMemoryBarrier(GL_SHADER_STORAGE_BARRIER_BIT);

		instance->simulationFrame++;
    }

    void HairRender::Render(const AfroInst* instance, const Matrix4& viewMatrix, const Matrix4& projectionMatrix) const
    {
        auto asset = instance->asset;
        auto settings = instance->settings;
        auto viewProjectionMatrix = projectionMatrix * viewMatrix;
        int verticesPerStrand = asset->segmentsCount + 1; 


        glEnable(GL_DEPTH_TEST);
        glBindBufferBase(GL_SHADER_STORAGE_BUFFER, REST_POSITIONS_BUFFER_BINDING, asset->restPositionsBufferID);
        glBindBufferBase(GL_SHADER_STORAGE_BUFFER, POSITIONS_BUFFER_BINDING, instance->positionsBufferID);
        glBindBufferBase(GL_SHADER_STORAGE_BUFFER, PREVIOUS_POSITIONS_BUFFER_BINDING, instance->prevPossBufferID);
        glBindBufferBase(GL_SHADER_STORAGE_BUFFER, HAIR_INDICES_BUFFER_BINDING, asset->hairIndicesBufferID);
        glBindBufferBase(GL_SHADER_STORAGE_BUFFER, TANGENTS_DISTANCES_BINDING, asset->tangentsDistancesBufferID);

        if (settings.visualizeGuides) {
            glUseProgram(guidesVisualizationProgramID);

            glUniformMatrix4fv(glGetUniformLocation(guidesVisualizationProgramID, "viewProjectionMatrix"), 1, false, (float*)viewProjectionMatrix.m);
            glUniform1i(glGetUniformLocation(guidesVisualizationProgramID, "doubleSegments"), asset->segmentsCount * 2);
            glUniform1i(glGetUniformLocation(guidesVisualizationProgramID, "verticesPerStrand"), verticesPerStrand);
            glUniform4f(glGetUniformLocation(guidesVisualizationProgramID, "color"), 1, 0, 0, 1);

            glBindVertexArray(emptyVertexArrayID);
            glDrawArrays(GL_LINES, 0, asset->guidesCount * asset->segmentsCount * 2);
            glUseProgram(0);
        }
        
        if (instance->settings.visualizeGrowthMesh) {
            glUseProgram(growthMeshVisualizationProgramID);

            glUniformMatrix4fv(glGetUniformLocation(growthMeshVisualizationProgramID, "viewProjectionMatrix"), 1, false, (float*)viewProjectionMatrix.m);
            glUniform1i(glGetUniformLocation(growthMeshVisualizationProgramID, "verticesPerStrand"), verticesPerStrand); //
            glUniform4f(glGetUniformLocation(growthMeshVisualizationProgramID, "color"), 1, 1, 0, 1); //

            glBindVertexArray(emptyVertexArrayID);
            glDrawArrays(GL_LINES, 0, asset->trianglesCount * 6);
            glUseProgram(0);
        }

        if (instance->settings.renderHair) {
            auto inversedViewMatrix = viewMatrix.EuclidianInversed(); // t is supposed to be transposed, but it is not

            HairRenderData hairRenderData = {};
            hairRenderData.tessFact = settings.tessFact;
            hairRenderData.segmentsCount = instance->asset->segmentsCount;
            hairRenderData.rootWidth = settings.rootWidth;
            hairRenderData.tipWidth = settings.tipWidth;
            hairRenderData.density = settings.density;
            hairRenderData.color = settings.color;
            hairRenderData.hairCurliness = settings.hairCurliness;
            hairRenderData.startThin = settings.startThin;

            SceneRenderData sceneRenderData = {};
            sceneRenderData.viewProjectionMatrix = viewProjectionMatrix;
            sceneRenderData.eyePosition = inversedViewMatrix.m[3].XYZ();

            LightRenderData lightData = {};
            lightData.lightsCount = 1;
            lightData.lights[0].position = { 5, 5, 5 };
            lightData.lights[0].color = { 1, 1, 1, 1 };

            glBindBuffer(GL_UNIFORM_BUFFER, hairDataBufferID);
            glBufferData(GL_UNIFORM_BUFFER, sizeof(HairRenderData), &hairRenderData, GL_DYNAMIC_DRAW);
            glBindBuffer(GL_UNIFORM_BUFFER, 0);

            glBindBuffer(GL_UNIFORM_BUFFER, sceneDataBufferID);
            glBufferData(GL_UNIFORM_BUFFER, sizeof(SceneRenderData), &sceneRenderData, GL_DYNAMIC_DRAW);
            glBindBuffer(GL_UNIFORM_BUFFER, 0);

            glBindBuffer(GL_UNIFORM_BUFFER, lightDataBufferID);
            glBufferData(GL_UNIFORM_BUFFER, sizeof(LightRenderData), &lightData, GL_DYNAMIC_DRAW);
            glBindBuffer(GL_UNIFORM_BUFFER, 0);

            glBindBufferBase(GL_SHADER_STORAGE_BUFFER, POSITIONS_BUFFER_BINDING, instance->positionsBufferID);
            glBindBufferBase(GL_SHADER_STORAGE_BUFFER, HAIR_INDICES_BUFFER_BINDING, asset->hairIndicesBufferID);

            glUseProgram(hairRenderingProgramID);

            glBindBufferRange(GL_UNIFORM_BUFFER, HAIR_DATA_BINDING, hairDataBufferID, 0, sizeof(HairRenderData));
            glBindBufferRange(GL_UNIFORM_BUFFER, SCENE_DATA_BINDING, sceneDataBufferID, 0, sizeof(SceneRenderData));
            glBindBufferRange(GL_UNIFORM_BUFFER, LIGHT_DATA_BINDING, lightDataBufferID, 0, sizeof(LightRenderData));

            glPatchParameteri(GL_PATCH_VERTICES, 1);
            glDrawArrays(GL_PATCHES, 0, asset->trianglesCount * asset->segmentsCount);
            glUseProgram(0);
        }
    }

    uint32_t HairRender::CreateSimulationProgram() // this is the program that simulates the hair strands (it is a compute shader)
    {
        auto simulationShaderSource = LoadFile("afrohairglshaders/Simulation.comp");
        uint32_t simulationShaderID = CompileShader(GLSLVersion, simulationShaderSource, GL_COMPUTE_SHADER, &shaderIncludeSrc);
        return LinkProgram(simulationShaderID);
    }

    uint32_t HairRender::CreateHairRenderingProgram() // this is the program that renders the hair strands (it is a vertex shader)
    {
        auto hairVertexShaderSource = LoadFile("afrohairglshaders/Hair.vert");
        auto hairTessControlShaderSource = LoadFile("afrohairglshaders/Hair.tesc");
        auto hairTessEvaluationShaderSource = LoadFile("afrohairglshaders/Hair.tese");
        auto hairGeometrylShaderSource = LoadFile("afrohairglshaders/Hair.geom");
        auto hairFragmentShaderSource = LoadFile("afrohairglshaders/Hair.frag");

        uint32_t hairVertexShaderID = CompileShader(GLSLVersion, hairVertexShaderSource, GL_VERTEX_SHADER, &shaderIncludeSrc);
        uint32_t hairTessControlShaderID = CompileShader(GLSLVersion, hairTessControlShaderSource, GL_TESS_CONTROL_SHADER, &shaderIncludeSrc);
        uint32_t hairTessEvaluationShaderID = CompileShader(GLSLVersion, hairTessEvaluationShaderSource, GL_TESS_EVALUATION_SHADER, &shaderIncludeSrc);
        uint32_t hairGeometryShaderID = CompileShader(GLSLVersion, hairGeometrylShaderSource, GL_GEOMETRY_SHADER, &shaderIncludeSrc);
        uint32_t hairFragmentShaderID = CompileShader(GLSLVersion, hairFragmentShaderSource, GL_FRAGMENT_SHADER, &shaderIncludeSrc);

        uint32_t programID = LinkProgram(hairVertexShaderID, hairTessControlShaderID, hairTessEvaluationShaderID, hairGeometryShaderID, hairFragmentShaderID);

        glDeleteShader(hairVertexShaderID);
        glDeleteShader(hairTessControlShaderID);
        glDeleteShader(hairTessEvaluationShaderID);
        glDeleteShader(hairGeometryShaderID);
        glDeleteShader(hairFragmentShaderID);

        return programID;
    }
	
    HairRender::~HairRender()
    {
        glFinish();

        glDeleteProgram(guidesVisualizationProgramID);
        glDeleteProgram(hairRenderingProgramID);
        glDeleteProgram(simulationProgramID);
        glDeleteVertexArrays(1, &emptyVertexArrayID);
    }
}