#ifndef AFROHAIRGL_COMMON_H
#define AFROHAIRGL_COMMON_H

#include <stdint.h>
#include <afrohairgl/HairTypes.h>
#include <string>

namespace AfroHairGL
{
    class HairAsset
    {
    public:
        uint32_t restPositionsBufferID;
        uint32_t tangentsDistancesBufferID;
        uint32_t hairIndicesBufferID;
		uint32_t refVectorsBufferID;
		uint32_t globalRotationsBufferID;
		uint32_t debugBufferID;
        uint32_t segmentsCount;
        uint32_t guidesCount;
        uint32_t trianglesCount;
    };

    class AfroInst
    {
    public:
        const HairAsset* asset;
        AfroInstSettings settings;
        uint32_t positionsBufferID;
        uint32_t prevPossBufferID;
		uint32_t simulationFrame;
    };

    std::string LoadFile(const char* path);
}

#endif