#include "Afroapp.h"
#include <iostream>
#include <imgui.h>
#include <imgui_impl_glfw.h>
#include <imgui_impl_opengl3.h>

Afroapp::Afroapp(const char* windowTitle, int initialScreenWidth, int initialScreenHeight)
    : systHair(nullptr),
    assetHair(nullptr),
    hairInst(nullptr),
    cameraController(nullptr) {
    if (glfwInit() == GLFW_FALSE) {
        throw std::runtime_error("Cannot initialise GLFW.");
    }

    window = glfwCreateWindow(initialScreenWidth, initialScreenHeight, windowTitle, nullptr, nullptr);
    glfwMakeContextCurrent(window);

    systHair = new AfroHairGL::HairSystem();

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui::StyleColorsClassic();

    ImGui_ImplGlfw_InitForOpenGL(window, true);
    ImGui_ImplOpenGL3_Init();

    assetHair = systHair->LoadAsset("data/hair.hgl");
    hairInst = systHair->CreateInstance(assetHair);
    Parameters.modelMatrix.SetIdentity();
    Parameters.tipWidth = 0.0001f;  // size is in same units as the hair asset
    Parameters.color = { 0.8f, 0.5f, 0.3f, 1.0f };
    cameraController = new CameraController(window);
}

void Afroapp::Run()
{
    glfwShowWindow(window);

    while (!glfwWindowShouldClose(window)) {
        glfwPollEvents();
        Update(1.0f / 60.0f);
        Render();
    }
}

void Afroapp::Update(float timeStep) {
    cameraController->Update();

    // Initialising ImGui
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplGlfw_NewFrame();
    ImGui::NewFrame();

    // Create the "Parameters" window
    ImVec2 settingsWindowPosition = ImVec2(10, 10);
    ImVec2 settingsWindowSize = ImVec2(400, 430);
    ImGui::SetNextWindowPos(settingsWindowPosition);
    ImGui::SetNextWindowSizeConstraints(settingsWindowSize, settingsWindowSize);
    ImGui::Begin("Parameters", 0, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings);

    // Render hair checkbox
    ImGui::Checkbox("Render Hair", &Parameters.renderHair);

    // Editing the colors
    ImGui::ColorEdit3("Colour", Parameters.color.m);

    // Sliders for Parameters
    ImGui::SliderFloat("Density", &Parameters.density, 3.0f, 64.0f);
    ImGui::SliderFloat("Length", &Parameters.length, 0.01f, 0.1f);
    ImGui::SliderFloat("Tip Width", &Parameters.tipWidth, 0.0f, 0.01f);
    ImGui::SliderFloat("Global Stiffness", &Parameters.stiffGlobal, 0.0f, 1.0f);
    ImGui::SliderFloat("Local Stiffness", &Parameters.stiffLocal, 0.0f, 1.0f);
    ImGui::SliderFloat("Hair Curliness", &Parameters.damping, 0.0f, 0.5f);

    // End the "Parameters" window
    ImGui::End();

    // Render the hair
    ImGui::Render();

    // Update the instance settings
    systHair->UpdateInstanceSettings(hairInst, Parameters);

    // Simulate the hair
    systHair->Simulate(hairInst, timeStep);
}

void Afroapp::Render() {
    int screenWidth, screenHeight;
    glfwGetFramebufferSize(window, &screenWidth, &screenHeight);
    glViewport(0, 0, screenWidth, screenHeight);

    // Get the view matrix from the camera controller
    auto viewMatrix = cameraController->GetViewMatrix();

    // Get the projection matrix
    auto projectionMatrix = AfroHairGL::Matrix4::Perspective(AfroHairGL::DegToRad * 100.0f, (float)screenWidth / (float)screenHeight, 0.01f, 100.0f);

    // Clear the screen
    glClearColor(0.9f, 0.9f, 0.9f, 1);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Render the hair
    systHair->Render(hairInst, viewMatrix, projectionMatrix);

    // Render the ImGui UI
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

    // Swap the buffers
    glfwSwapBuffers(window);
}

Afroapp::~Afroapp() {
    // Shutdown ImGui
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();

    // Destroy the hair instance
    systHair->DestroyInstance(hairInst);
    systHair->DestroyAsset(assetHair);
    delete systHair;

    // Delete the camera controller
    delete cameraController;

    // Destroy the GLFW window
    glfwDestroyWindow(window);

    // Terminate GLFW
    glfwTerminate();
}