#include "Afroapp.h"
#include <iostream>

int main()
{
    try {
        Afroapp app("AfroHairGL", 1280, 720);
        app.Run();
    }
    catch (std::exception e) {
        std::cerr << e.what() << std::endl;
        return -1;
    }
    return 0;
}