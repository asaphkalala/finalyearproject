#ifndef APPLICATION_H
#define APPLICATION_H

#include <GLFW/glfw3.h>
#include <afrohairgl/AfroHairGL.h>
#include "CameraController.h"

class Afroapp
{
public:
    Afroapp(const char* windowTitle, int initialScreenWidth, int initialScreenHeight);
    void Run();
    ~Afroapp();

private:
    GLFWwindow* window;
    AfroHairGL::HairSystem* systHair;
    AfroHairGL::HairAsset* assetHair;
    AfroHairGL::AfroInst* hairInst;
    AfroHairGL::AfroInstSettings Parameters;
    CameraController* cameraController;
    void Render();
    void Update(float timeStep);
};

#endif