#include "CameraController.h"
#include <cmath>

CameraController::CameraController(GLFWwindow* window): 
    window(window),
    target(AfroHairGL::Vector3()),
    distance(0.5f),
    pitch(0),
    yaw(0),
    zoomSensitivity(0.05f),
    sensitivity(0.005f),
    isDragging(false),
    dragPrevious(AfroHairGL::Vector3()),
    dragMode(DragMode::Rotation)
{
    glfwSetWindowUserPointer(window, this); // Set the user pointer to this instance so that we can access it in the callback function.
    glfwSetScrollCallback(window, ScrollCallback); // Set the scroll callback function.
}
AfroHairGL::Matrix4 CameraController::GetViewMatrix() const
{
    auto position = GetPosition();
    auto viewMatrix = AfroHairGL::Matrix4::LookAt(position, target, AfroHairGL::Vector3(0, 1, 0)); // Look at the target from the position.
    return viewMatrix;
}
AfroHairGL::Vector3 CameraController::GetPosition() const
{
    AfroHairGL::Vector4 offset(0, 0, distance, 1.0f); // The offset from the target.
    // Rotate the offset vertically and vertically.
    auto verticalRotation = AfroHairGL::Matrix4::RotateX(pitch); 
    auto horizontalRotation = AfroHairGL::Matrix4::RotateY(yaw); 
    // Apply the rotations to the offset.
    offset = verticalRotation * AfroHairGL::Vector4(offset.x, offset.y, offset.z, 1); 
    offset = horizontalRotation * AfroHairGL::Vector4(offset.x, offset.y, offset.z, 1);

    return target + offset.XYZ(); // Return the position.
}
void CameraController::Update() 
{
    SetDistance(distance);

    // If the right mouse button or the middle mouse button is pressed, drag the camera.
    
    if (glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_2) != GLFW_RELEASE || glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_3) != GLFW_RELEASE) {
        double currentMousePosX;
        double currentMousePosY;
        glfwGetCursorPos(window, &currentMousePosX, &currentMousePosY);
        AfroHairGL::Vector3 currentMousePosition(currentMousePosX, currentMousePosY, 0);
// If the mouse is not dragging, set the drag mode and the previous mouse position.
        if (!isDragging) {
            isDragging = true;
            dragPrevious = currentMousePosition;
            dragMode = glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_2) != GLFW_RELEASE ? DragMode::Rotation : DragMode::Translation;
        }
        OnDrag(currentMousePosition - dragPrevious, dragMode);
        dragPrevious = currentMousePosition;
    }
    else {
        isDragging = false;
    }
}
void CameraController::SetDistance(float distance)
{
    this->distance = std::fmax(distance, 0.01f); 

}
// Set the pitch and the yaw to the given values
void CameraController::SetPitch(float pitch)
{
    if (pitch >= AfroHairGL::PI / 2) {
        pitch = AfroHairGL::PI / 2 - 0.00001f;
    }

    if (pitch <= -AfroHairGL::PI / 2) {
        pitch = -AfroHairGL::PI / 2 + 0.00001f;
    }

    this->pitch = pitch;
}
void CameraController::SetYaw(float yaw)
{
    if (yaw > AfroHairGL::PI * 2) {
        yaw = 0;
    }

    this->yaw = yaw;
}
void CameraController::SetSensitivity(float sensitivity)
{
    this->sensitivity = std::fmax(sensitivity, 0.0f);
}
void CameraController::SetZoomSensitivity(float zoomSensitivity)
{
    this->zoomSensitivity = std::fmax(zoomSensitivity, 0.0f);
}
void CameraController::Pan(const AfroHairGL::Vector3& offset)
{
    auto forward = (target - GetPosition()).Normalized();
    auto right = AfroHairGL::Vector3::Cross(forward, AfroHairGL::Vector3(0, 1, 0)).Normalized();
    auto up = AfroHairGL::Vector3::Cross(right, forward);
    target += up * offset.y * sensitivity - right * offset.x * sensitivity;
}
void CameraController::OnScroll(double xoffset, double yoffset)
{
    SetDistance(distance - yoffset * zoomSensitivity);
}
void CameraController::ScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    auto controller = static_cast<CameraController*>(glfwGetWindowUserPointer(window));
    controller->OnScroll(xoffset, yoffset);
}
// Rotate the camera by the given offset.
void CameraController::OnDrag(const AfroHairGL::Vector3& offset, DragMode dragMode)
{
    if (dragMode == DragMode::Rotation) {
        SetPitch(pitch + offset.y * sensitivity);
        SetYaw(yaw + offset.x * sensitivity);
    }
    else if (dragMode == DragMode::Translation) {
        Pan(offset);
    }
}
CameraController::~CameraController()
{
    glfwSetWindowUserPointer(window, nullptr);
    glfwSetScrollCallback(window, nullptr);
}
